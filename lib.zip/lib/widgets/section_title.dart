import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(title,
            style:
                const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
        const Spacer(),
        Text('See all',
            style: TextStyle(
                color: AppTheme.goldDark,
                fontSize: 12,
                fontWeight: FontWeight.w600)),
      ],
    );
  }
}
